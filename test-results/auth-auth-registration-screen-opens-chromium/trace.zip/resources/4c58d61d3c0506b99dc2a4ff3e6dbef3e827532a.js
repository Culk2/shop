(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__28bc9c2a._.css",
  "static/chunks/node_modules_@clerk_nextjs_dist_esm_app-router_b17ade04._.js",
  "static/chunks/node_modules_a10cf04c._.js",
  "static/chunks/app_components_header_tsx_fca9809c._.js"
],
    source: "dynamic"
});
