(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/actions/data:da0810 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"4077d7adf4cda3e8a39265e658bca589e425bada21":"addToCartAction"},"app/actions/cart.ts",""] */ __turbopack_context__.s([
    "addToCartAction",
    ()=>addToCartAction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var addToCartAction = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("4077d7adf4cda3e8a39265e658bca589e425bada21", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "addToCartAction"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vY2FydC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBhcHAvYWN0aW9ucy9jYXJ0LnRzXG4ndXNlIHNlcnZlcidcblxuaW1wb3J0IHsgZGF0YUNsaWVudCB9IGZyb20gJ0AvbGliL2RhdGFDbGllbnQnXG5pbXBvcnQgeyBnZXRVc2VySWQgfSBmcm9tICdAL2xpYi9hdXRoJ1xuaW1wb3J0IHsgcmV2YWxpZGF0ZVBhdGggfSBmcm9tICduZXh0L2NhY2hlJ1xuXG50eXBlIENhcnRJdGVtID0ge1xuICBfa2V5OiBzdHJpbmdcbiAgcHJvZHVjdElkOiBzdHJpbmdcbiAgbmFtZTogc3RyaW5nXG4gIHByaWNlOiBudW1iZXJcbiAgaW1hZ2VVcmw/OiBzdHJpbmcgfCBudWxsXG4gIHNpemU/OiBzdHJpbmcgfCBudWxsXG4gIGNvbG9yPzogc3RyaW5nIHwgbnVsbFxuICBxdWFudGl0eTogbnVtYmVyXG59XG5cbnR5cGUgQ2FydERvYyA9IHtcbiAgX2lkOiBzdHJpbmdcbiAgaXRlbXM/OiBDYXJ0SXRlbVtdXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZGRUb0NhcnRBY3Rpb24ocHJvZHVjdDoge1xuICBfaWQ6IHN0cmluZ1xuICBuYW1lOiBzdHJpbmdcbiAgcHJpY2U6IG51bWJlclxuICBpbWFnZVVybD86IHN0cmluZyB8IG51bGxcbiAgc2l6ZT86IHN0cmluZyB8IG51bGxcbiAgY29sb3I/OiBzdHJpbmcgfCBudWxsXG4gIHF1YW50aXR5PzogbnVtYmVyXG59KSB7XG4gIGNvbnN0IHVzZXJJZCA9IGF3YWl0IGdldFVzZXJJZCgpXG4gIGlmICghdXNlcklkKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdOaXNpIHByaWphdmxqZW4nIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHF0eSA9IHByb2R1Y3QucXVhbnRpdHkgfHwgMVxuICAgIGNvbnN0IF9rZXkgPSBjcnlwdG8ucmFuZG9tVVVJRD8uKCkgPz8gRGF0ZS5ub3coKS50b1N0cmluZygzNilcblxuICAgIGxldCBjYXJ0ID0gKGF3YWl0IGRhdGFDbGllbnQuZmV0Y2goXG4gICAgICBgKltfdHlwZSA9PSBcImNhcnRcIiAmJiB1c2VySWQgPT0gJHVzZXJJZF1bMF17IF9pZCwgaXRlbXMgfWAsXG4gICAgICB7IHVzZXJJZCB9XG4gICAgKSkgYXMgQ2FydERvYyB8IG51bGxcblxuICAgIGlmICghY2FydCkge1xuICAgICAgY2FydCA9IChhd2FpdCBkYXRhQ2xpZW50LmNyZWF0ZSh7XG4gICAgICAgIF90eXBlOiAnY2FydCcsXG4gICAgICAgIHVzZXJJZCxcbiAgICAgICAgaXRlbXM6IFtdLFxuICAgICAgfSkpIGFzIENhcnREb2NcbiAgICB9XG5cbiAgICBjb25zdCBjYXJ0SWQgPSBjYXJ0Ll9pZFxuXG4gICAgY29uc3QgZXhpc3RpbmcgPSBjYXJ0Lml0ZW1zPy5maW5kKFxuICAgICAgKGkpID0+XG4gICAgICAgIGkucHJvZHVjdElkID09PSBwcm9kdWN0Ll9pZCAmJlxuICAgICAgICBpLnNpemUgPT09IHByb2R1Y3Quc2l6ZSAmJlxuICAgICAgICBpLmNvbG9yID09PSBwcm9kdWN0LmNvbG9yXG4gICAgKVxuXG4gICAgaWYgKGV4aXN0aW5nKSB7XG4gICAgICBhd2FpdCBkYXRhQ2xpZW50XG4gICAgICAgIC5wYXRjaChjYXJ0SWQpXG4gICAgICAgIC5zZXQoeyBbYGl0ZW1zW19rZXk9PVwiJHtleGlzdGluZy5fa2V5fVwiXS5xdWFudGl0eWBdOiBleGlzdGluZy5xdWFudGl0eSArIHF0eSB9KVxuICAgICAgICAuY29tbWl0KHsgcmV0dXJuRG9jdW1lbnRzOiBmYWxzZSB9KVxuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBkYXRhQ2xpZW50XG4gICAgICAgIC5wYXRjaChjYXJ0SWQpXG4gICAgICAgIC5zZXRJZk1pc3NpbmcoeyBpdGVtczogW10gfSlcbiAgICAgICAgLmFwcGVuZCgnaXRlbXMnLCBbe1xuICAgICAgICAgIF9rZXksXG4gICAgICAgICAgcHJvZHVjdElkOiBwcm9kdWN0Ll9pZCxcbiAgICAgICAgICBuYW1lOiBwcm9kdWN0Lm5hbWUsXG4gICAgICAgICAgcHJpY2U6IHByb2R1Y3QucHJpY2UsXG4gICAgICAgICAgaW1hZ2VVcmw6IHByb2R1Y3QuaW1hZ2VVcmwsXG4gICAgICAgICAgc2l6ZTogcHJvZHVjdC5zaXplLFxuICAgICAgICAgIGNvbG9yOiBwcm9kdWN0LmNvbG9yLFxuICAgICAgICAgIHF1YW50aXR5OiBxdHksXG4gICAgICAgIH1dKVxuICAgICAgICAuY29tbWl0KHsgcmV0dXJuRG9jdW1lbnRzOiBmYWxzZSB9KVxuICAgIH1cblxuICAgIHJldmFsaWRhdGVQYXRoKCcvY2FydCcpXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9zaG9wJylcblxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGNhcnRJZCB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ2FkZFRvQ2FydEFjdGlvbiBlcnJvcjonLCBlcnIpXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnTmFwYWthIHByaSBkb2RhamFuanUnIH1cbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlQ2FydFF1YW50aXR5KGNhcnRJZDogc3RyaW5nLCBpdGVtS2V5OiBzdHJpbmcsIHF1YW50aXR5OiBudW1iZXIpIHtcbiAgaWYgKHF1YW50aXR5IDwgMSkgcXVhbnRpdHkgPSAxXG5cbiAgY29uc3QgdXNlcklkID0gYXdhaXQgZ2V0VXNlcklkKClcbiAgaWYgKCF1c2VySWQpIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ05pc2kgcHJpamF2bGplbicgfVxuXG4gIGlmICghY2FydElkKSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdNYW5qa2EgY2FydElkJyB9XG5cbiAgdHJ5IHtcbiAgICBhd2FpdCBkYXRhQ2xpZW50XG4gICAgICAucGF0Y2goY2FydElkKVxuICAgICAgLnNldCh7IFtgaXRlbXNbX2tleT09XCIke2l0ZW1LZXl9XCJdLnF1YW50aXR5YF06IHF1YW50aXR5IH0pXG4gICAgICAuY29tbWl0KHsgcmV0dXJuRG9jdW1lbnRzOiBmYWxzZSB9KVxuXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9jYXJ0JylcblxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKCd1cGRhdGVDYXJ0UXVhbnRpdHkgZXJyb3I6JywgZXJyKVxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ05hcGFrYSBwcmkgcG9zb2RvYml0dmknIH1cbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVtb3ZlRnJvbUNhcnRBY3Rpb24oY2FydElkOiBzdHJpbmcsIGl0ZW1LZXk6IHN0cmluZykge1xuICBjb25zdCB1c2VySWQgPSBhd2FpdCBnZXRVc2VySWQoKVxuICBpZiAoIXVzZXJJZCkgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnTmlzaSBwcmlqYXZsamVuJyB9XG5cbiAgaWYgKCFjYXJ0SWQpIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ01hbmprYSBjYXJ0SWQnIH1cbiAgaWYgKCFpdGVtS2V5KSByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdNYW5qa2EgaXRlbUtleScgfVxuXG4gIHRyeSB7XG4gICAgYXdhaXQgZGF0YUNsaWVudFxuICAgICAgLnBhdGNoKGNhcnRJZClcbiAgICAgIC51bnNldChbYGl0ZW1zW19rZXk9PVwiJHtpdGVtS2V5fVwiXWBdKVxuICAgICAgLmNvbW1pdCh7IHJldHVybkRvY3VtZW50czogZmFsc2UgfSlcblxuICAgIHJldmFsaWRhdGVQYXRoKCcvY2FydCcpXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9zaG9wJylcblxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKCdyZW1vdmVGcm9tQ2FydEFjdGlvbiBlcnJvcjonLCBlcnIpXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAoZXJyIGFzIEVycm9yKS5tZXNzYWdlIHx8ICdOYXBha2EgcHJpIGJyaXNhbmp1JyB9XG4gIH1cbn1cclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI0UkF1QnNCIn0=
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ProductCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProductCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$da0810__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/actions/data:da0810 [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function ProductCard({ product }) {
    _s();
    const [showModal, setShowModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [addedToCart, setAddedToCart] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [quantity, setQuantity] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [isPending, startTransition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const isE2E = ("TURBOPACK compile-time value", "1") === '1';
    const getCategoryName = (category)=>{
        if (!category) return null;
        if (typeof category === 'string') return category;
        return category.title ?? null;
    };
    const categoryName = getCategoryName(product.category);
    const normalizedCategory = typeof categoryName === 'string' ? categoryName.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '') : null;
    const isShoes = typeof normalizedCategory === 'string' && (normalizedCategory.includes('cevl') || normalizedCategory.includes('obutev') || normalizedCategory.includes('cevlji'));
    const sizeOptions = Array.isArray(product.sizes) && product.sizes.length > 0 ? product.sizes : isShoes ? [
        '36',
        '37',
        '38',
        '39',
        '40',
        '41',
        '42',
        '43',
        '44',
        '45',
        '46'
    ] : [
        'S',
        'M',
        'L',
        'XL'
    ];
    const handleAddToCart = async (event)=>{
        event.preventDefault();
        startTransition(async ()=>{
            try {
                const form = new FormData(event.currentTarget);
                const productData = JSON.parse(form.get('product'));
                const size = form.get('size');
                const color = form.get('color');
                const qty = parseInt(form.get('quantity'), 10) || 1;
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$actions$2f$data$3a$da0810__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["addToCartAction"])({
                    ...productData,
                    size,
                    color,
                    quantity: qty
                });
                setAddedToCart(true);
                setTimeout(()=>setAddedToCart(false), 2000);
                router.refresh();
            } catch (error) {
                console.error('Napaka pri dodajanju v košarico:', error);
                alert('Pri dodajanju je prišlo do napake. Poskusi ponovno.');
            }
        });
    };
    const form = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        onSubmit: handleAddToCart,
        className: "w-full space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "hidden",
                name: "product",
                value: JSON.stringify(product)
            }, void 0, false, {
                fileName: "[project]/app/components/ProductCard.tsx",
                lineNumber: 81,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "text-black mb-1",
                        children: "Velikost"
                    }, void 0, false, {
                        fileName: "[project]/app/components/ProductCard.tsx",
                        lineNumber: 84,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        name: "size",
                        required: true,
                        className: "border p-3 rounded text-black",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "Izberi velikost"
                            }, void 0, false, {
                                fileName: "[project]/app/components/ProductCard.tsx",
                                lineNumber: 86,
                                columnNumber: 11
                            }, this),
                            sizeOptions.map((opt)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: opt,
                                    children: opt
                                }, opt, false, {
                                    fileName: "[project]/app/components/ProductCard.tsx",
                                    lineNumber: 88,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/ProductCard.tsx",
                        lineNumber: 85,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/ProductCard.tsx",
                lineNumber: 83,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "text-black mb-1",
                        children: "Barva"
                    }, void 0, false, {
                        fileName: "[project]/app/components/ProductCard.tsx",
                        lineNumber: 96,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        name: "color",
                        required: true,
                        className: "border p-3 rounded text-black",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "Izberi barvo"
                            }, void 0, false, {
                                fileName: "[project]/app/components/ProductCard.tsx",
                                lineNumber: 98,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                children: "Črna"
                            }, void 0, false, {
                                fileName: "[project]/app/components/ProductCard.tsx",
                                lineNumber: 99,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                children: "Bela"
                            }, void 0, false, {
                                fileName: "[project]/app/components/ProductCard.tsx",
                                lineNumber: 100,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                children: "Rdeča"
                            }, void 0, false, {
                                fileName: "[project]/app/components/ProductCard.tsx",
                                lineNumber: 101,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                children: "Modra"
                            }, void 0, false, {
                                fileName: "[project]/app/components/ProductCard.tsx",
                                lineNumber: 102,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/ProductCard.tsx",
                        lineNumber: 97,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/ProductCard.tsx",
                lineNumber: 95,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "text-black mb-1",
                        children: "Količina"
                    }, void 0, false, {
                        fileName: "[project]/app/components/ProductCard.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "number",
                        name: "quantity",
                        min: 1,
                        value: quantity,
                        onChange: (e)=>setQuantity(Number(e.target.value) || 1),
                        className: "border p-3 rounded text-black",
                        disabled: isPending
                    }, void 0, false, {
                        fileName: "[project]/app/components/ProductCard.tsx",
                        lineNumber: 108,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/ProductCard.tsx",
                lineNumber: 106,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "submit",
                disabled: isPending,
                className: `w-full mt-6 py-4 rounded-xl text-xl font-bold transition
          ${isPending ? 'bg-gray-400 cursor-not-allowed' : addedToCart ? 'bg-green-600 text-white' : 'bg-indigo-600 text-white hover:bg-indigo-700'}`,
                children: isPending ? 'Dodajam...' : addedToCart ? 'Dodano v košarico ✓' : 'Dodaj v košarico'
            }, void 0, false, {
                fileName: "[project]/app/components/ProductCard.tsx",
                lineNumber: 119,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/ProductCard.tsx",
        lineNumber: 80,
        columnNumber: 5
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>setShowModal(true),
                className: "w-full text-left group block",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white rounded-xl shadow-md hover:shadow-2xl transition-all duration-300 overflow-hidden transform hover:-translate-y-2",
                    children: [
                        product.imageUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative aspect-square bg-gray-100 overflow-hidden",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: `${product.imageUrl}?w=800&h=800&fit=crop&auto=format`,
                                alt: product.name,
                                className: "w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                            }, void 0, false, {
                                fileName: "[project]/app/components/ProductCard.tsx",
                                lineNumber: 145,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/components/ProductCard.tsx",
                            lineNumber: 144,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-gray-200 border-2 border-dashed rounded-t-xl w-full aspect-square flex items-center justify-center",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-black text-lg font-medium",
                                children: "Brez slike"
                            }, void 0, false, {
                                fileName: "[project]/app/components/ProductCard.tsx",
                                lineNumber: 153,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/components/ProductCard.tsx",
                            lineNumber: 152,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-6 pb-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-xl font-semibold text-black mb-2",
                                    children: product.name
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ProductCard.tsx",
                                    lineNumber: 158,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-3xl font-bold text-indigo-600",
                                    children: [
                                        product.price.toFixed(2),
                                        " €"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/ProductCard.tsx",
                                    lineNumber: 161,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/ProductCard.tsx",
                            lineNumber: 157,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/ProductCard.tsx",
                    lineNumber: 142,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/ProductCard.tsx",
                lineNumber: 141,
                columnNumber: 7
            }, this),
            showModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 bg-black bg-opacity-70 z-50 flex items-center justify-center p-4",
                onClick: ()=>setShowModal(false),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white rounded-3xl max-w-5xl w-full max-h-[90vh] overflow-y-auto shadow-2xl relative",
                    onClick: (e)=>e.stopPropagation(),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setShowModal(false),
                            className: "absolute top-6 right-6 bg-white rounded-full p-3 shadow-lg text-3xl font-bold text-black",
                            children: "×"
                        }, void 0, false, {
                            fileName: "[project]/app/components/ProductCard.tsx",
                            lineNumber: 178,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid md:grid-cols-2 gap-10 p-10",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "aspect-square bg-gray-50 rounded-2xl overflow-hidden",
                                    children: product.imageUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: `${product.imageUrl}?w=1400&h=1400&fit=crop&auto=format`,
                                        alt: product.name,
                                        className: "w-full h-full object-cover"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ProductCard.tsx",
                                        lineNumber: 188,
                                        columnNumber: 19
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-full h-full flex items-center justify-center text-black text-2xl",
                                        children: "Brez slike"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/ProductCard.tsx",
                                        lineNumber: 194,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/components/ProductCard.tsx",
                                    lineNumber: 186,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col justify-center space-y-8",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                            className: "text-5xl font-bold text-black",
                                            children: product.name
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/ProductCard.tsx",
                                            lineNumber: 201,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-6xl font-bold text-indigo-600",
                                            children: [
                                                product.price.toFixed(2),
                                                " €"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/components/ProductCard.tsx",
                                            lineNumber: 203,
                                            columnNumber: 17
                                        }, this),
                                        ("TURBOPACK compile-time truthy", 1) ? form : /*#__PURE__*/ "TURBOPACK unreachable",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>setShowModal(false),
                                            className: "text-center text-black font-medium text-lg",
                                            children: "Zapri"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/ProductCard.tsx",
                                            lineNumber: 223,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/ProductCard.tsx",
                                    lineNumber: 200,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/ProductCard.tsx",
                            lineNumber: 185,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/ProductCard.tsx",
                    lineNumber: 174,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/ProductCard.tsx",
                lineNumber: 170,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_s(ProductCard, "O+EoVzJGXuAt5a9kFyNv5tpTs/0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = ProductCard;
var _c;
__turbopack_context__.k.register(_c, "ProductCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/ProductsClient.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProductsClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ProductCard.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function ProductsClient({ products }) {
    _s();
    const [searchQuery, setSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [priceFilter, setPriceFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("all");
    const [categoryFilter, setCategoryFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("all");
    // vedno pretvori kategorijo v string
    const getCategoryName = (category)=>{
        if (!category) return null;
        if (typeof category === "string") return category;
        return category.title ?? null;
    };
    // kategorije
    const categories = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ProductsClient.useMemo[categories]": ()=>{
            return Array.from(new Set(products.map({
                "ProductsClient.useMemo[categories]": (p)=>getCategoryName(p.category)
            }["ProductsClient.useMemo[categories]"]).filter({
                "ProductsClient.useMemo[categories]": (c)=>Boolean(c)
            }["ProductsClient.useMemo[categories]"])));
        }
    }["ProductsClient.useMemo[categories]"], [
        products
    ]);
    // filtrirani izdelki
    const filteredProducts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ProductsClient.useMemo[filteredProducts]": ()=>{
            return products.filter({
                "ProductsClient.useMemo[filteredProducts]": (product)=>{
                    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase());
                    let matchesPrice = true;
                    if (priceFilter === "under20") matchesPrice = product.price < 20;
                    else if (priceFilter === "20to50") matchesPrice = product.price >= 20 && product.price <= 50;
                    else if (priceFilter === "over50") matchesPrice = product.price > 50;
                    const matchesCategory = categoryFilter === "all" || getCategoryName(product.category) === categoryFilter;
                    return matchesSearch && matchesPrice && matchesCategory;
                }
            }["ProductsClient.useMemo[filteredProducts]"]);
        }
    }["ProductsClient.useMemo[filteredProducts]"], [
        products,
        searchQuery,
        priceFilter,
        categoryFilter
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-7xl mx-auto",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-4xl sm:text-5xl font-bold text-gray-900",
                            children: "Naši izdelki"
                        }, void 0, false, {
                            fileName: "[project]/app/ProductsClient.tsx",
                            lineNumber: 64,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-2 flex-wrap",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "text",
                                    placeholder: "Išči izdelek...",
                                    value: searchQuery,
                                    onChange: (e)=>setSearchQuery(e.target.value),
                                    className: "px-4 py-2 border border-gray-300 rounded-lg bg-black text-white focus:outline-none focus:ring-2 focus:ring-indigo-600"
                                }, void 0, false, {
                                    fileName: "[project]/app/ProductsClient.tsx",
                                    lineNumber: 70,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: priceFilter,
                                    onChange: (e)=>setPriceFilter(e.target.value),
                                    className: "px-4 py-2 border border-gray-300 rounded-lg bg-black text-white focus:outline-none focus:ring-2 focus:ring-indigo-600",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "all",
                                            children: "Vse cene"
                                        }, void 0, false, {
                                            fileName: "[project]/app/ProductsClient.tsx",
                                            lineNumber: 84,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "under20",
                                            children: "Pod 20â‚¬"
                                        }, void 0, false, {
                                            fileName: "[project]/app/ProductsClient.tsx",
                                            lineNumber: 85,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "20to50",
                                            children: "20â‚¬ â€“ 50â‚¬"
                                        }, void 0, false, {
                                            fileName: "[project]/app/ProductsClient.tsx",
                                            lineNumber: 86,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "over50",
                                            children: "Nad 50â‚¬"
                                        }, void 0, false, {
                                            fileName: "[project]/app/ProductsClient.tsx",
                                            lineNumber: 87,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/ProductsClient.tsx",
                                    lineNumber: 79,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: categoryFilter,
                                    onChange: (e)=>setCategoryFilter(e.target.value),
                                    className: "px-4 py-2 border border-gray-300 rounded-lg bg-black text-white focus:outline-none focus:ring-2 focus:ring-indigo-600",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "all",
                                            children: "Vse kategorije"
                                        }, void 0, false, {
                                            fileName: "[project]/app/ProductsClient.tsx",
                                            lineNumber: 96,
                                            columnNumber: 15
                                        }, this),
                                        categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: cat,
                                                children: cat
                                            }, cat, false, {
                                                fileName: "[project]/app/ProductsClient.tsx",
                                                lineNumber: 98,
                                                columnNumber: 17
                                            }, this))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/ProductsClient.tsx",
                                    lineNumber: 91,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/ProductsClient.tsx",
                            lineNumber: 68,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/ProductsClient.tsx",
                    lineNumber: 63,
                    columnNumber: 9
                }, this),
                filteredProducts.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center py-20",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-lg text-gray-600",
                        children: "Ni najdenih izdelkov."
                    }, void 0, false, {
                        fileName: "[project]/app/ProductsClient.tsx",
                        lineNumber: 109,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/ProductsClient.tsx",
                    lineNumber: 108,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8",
                    children: filteredProducts.map((product)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            product: product
                        }, product._id, false, {
                            fileName: "[project]/app/ProductsClient.tsx",
                            lineNumber: 114,
                            columnNumber: 15
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/app/ProductsClient.tsx",
                    lineNumber: 112,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/ProductsClient.tsx",
            lineNumber: 60,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/ProductsClient.tsx",
        lineNumber: 59,
        columnNumber: 5
    }, this);
}
_s(ProductsClient, "VOQkJm48Gjx/HdgulM+OJfTKgys=");
_c = ProductsClient;
var _c;
__turbopack_context__.k.register(_c, "ProductsClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_15da5385._.js.map